---
name: awesome-design-md
description: Library of 74 ready-made DESIGN.md design systems (VoltAgent awesome-design-md) analysed from real products such as Linear, Stripe, Vercel, Notion, Apple, Airbnb, Spotify, Revolut, Uber, Supabase and Figma, each with colour tokens, type scale, components, layout and motion rules. Use when the user wants a site, app, page or component to look or feel like a named product ("make it like Linear", "Stripe-style"), asks for a design direction or design system to start from, or wants a DESIGN.md for their project. Works alongside the impeccable skill.
license: MIT
---

# Awesome DESIGN.md

74 DESIGN.md files, one per product, in `design-md/<name>/DESIGN.md`. A DESIGN.md is a plain-markdown design system an agent reads to build UI that stays visually consistent.

## How to use

1. Read [INDEX.md](INDEX.md) to find candidates. Do not read the whole library.
2. If the user named a product, open that file. If not, propose 2 or 3 that fit the brief with one line each on why, and let the user choose.
3. To adopt one, copy it to the project root as `DESIGN.md`, rename the system, swap in the user's own brand colours and fonts, and note the source at the top. Then build to it.
4. If the project already has a DESIGN.md or an established visual system, use the library only for comparison. Do not overwrite it unless the user asks for a redesign.

## Borrow the system, not the brand

Take structure, rhythm, type scale, density, spacing and interaction rules. Never copy another company's logo, name, wordmark, product copy or imagery, and never make the result look like it *is* that company. Proprietary fonts named in a file (Sohne, SF Pro, Circular, etc.) need a licensed or open substitute.

## With impeccable

If the impeccable skill is installed, it governs the craft and process. This library supplies the starting design system that impeccable's new-work flow treats as the incumbent DESIGN.md once adopted.

Source: https://github.com/VoltAgent/awesome-design-md (MIT, see LICENSE).
